#include <cmath>
#include <Rmath.h>
#include "RcppArmadillo.h"
// [[Rcpp::depends(RcppArmadillo)]]
using namespace arma;
using namespace Rcpp;


// [[Rcpp::export]]
arma::mat mvrnormArma(arma::mat Z,arma::vec mu, arma::mat sigma) {
  int n = Z.n_rows ;
  return arma::repmat(mu, 1, n).t() + Z * arma::chol(sigma);
}

// [[Rcpp::export]]

arma::vec RemNeg(arma::vec x, double y) {
  int n = x.size();
  arma::vec res(n); 
  for(int i = 0; i < n; i++){
    if (x[i] > y){res[i] = x[i];} else{res[i] = y;}
  }
  return trans(res)*y;
}



// [[Rcpp::export]]
arma::vec Log_likelihoodCpp(arma::mat xdata,arma::mat y,arma::mat distM,arma::vec para,arma::mat Z,double r01,double r02){
  int a = distM.n_rows, B=Z.n_rows, n=xdata.n_rows;
  arma::mat diag1(a,a),Gdist1(a,a),Gd1(a,a),C1(a,a),W11(B,a),W1(a,B),Gdist2(a,a),Gd2(a,a),C2(a,a),W22(B,a),W2(a,B);
  arma::vec mu(a), mu11(n),log_mu2(n),Loglk_Y1(n),log_like(n),Joint_pd(n),mu1(B),Ey1(B), mu2(B), Lk_Y1(B),u11(B),u22(B),u22_low(B),partial_lk(B);
  double r11,r12,Cl_Cop1,Cl_up,Cl_Cop2,Cl_low,Cl_diff;
  double sd1=pow(exp(para[3]),0.5);
  double tau1=1/(1+exp(-para[11]));
  double alpha_Cl=((2*tau1)/(1-tau1));
  
  mu.zeros();
  diag1.eye();
  r11= (exp(para[4]))*(exp(para[5]));
  Gdist1 = exp(-0.5*pow((distM/exp(para[5])),2));
  Gd1 = r11*Gdist1+r01*diag1;
  
  W11 = mvrnormArma(Z,mu, Gd1);
  W1 = W11.t();
  
  r12 = (exp(para[9]))*(exp(para[10]));
  Gdist2 = exp(-0.5*pow((distM/exp(para[10])),2));
  Gd2 = r12*Gdist2+r02*diag1;
  
  W22 = mvrnormArma(Z,mu, Gd2);
  W2 = W22.t();
  
  mu11 = para[0]+(para[1]*xdata.col(0))+(para[2]*xdata.col(1));
  log_mu2 = para[6]+(para[7]*(xdata.col(0))/30)+(para[8]*xdata.col(1));
  
  for(int i = 0; i < n; i++) {
    mu1 = mu11[i]+vectorise(W1.row(i));
    Ey1 = y(i,0)-mu1;
    u11 = normcdf(Ey1,0,sd1);
    Lk_Y1 = log(normpdf(Ey1,0,sd1));
    mu2 = exp(log_mu2[i]+vectorise(W2.row(i)));
    
    for(int j = 0; j < B; j++) {
      
    u22[j]=R::ppois(y(i,1),mu2[j],1,0);
    u22_low[j]=R::ppois(y(i,1)-1,mu2[j],1,0);
	  
	  Cl_Cop1 = pow(pow(u11[j],-alpha_Cl)+pow(u22[j],-alpha_Cl)-1,(-1/alpha_Cl));
		if(Cl_Cop1 < 0)
      Cl_Cop1= 0;
		if(Cl_Cop1 > 1)
      Cl_Cop1= 1;
    
    Cl_up = Cl_Cop1*(pow(u11[j],(-alpha_Cl-1))/(pow(u11[j],-alpha_Cl)+pow(u22[j],-alpha_Cl)-1));
    if(Cl_up < 0)
      Cl_up= 0;
    if(Cl_up > 1)
      Cl_up= 1;
    
    Cl_Cop2 = pow(pow(u11[j],-alpha_Cl)+pow(u22_low[j],-alpha_Cl)-1,(-1/alpha_Cl));
		if(Cl_Cop2 < 0)
      Cl_Cop2= 0;
		if(Cl_Cop2 > 1)
      Cl_Cop2= 1;
    
    Cl_low = Cl_Cop2*(pow(u11[j],(-alpha_Cl-1))/(pow(u11[j],-alpha_Cl)+pow(u22_low[j],-alpha_Cl)-1));
    if(Cl_low < 0)
      Cl_low= 0;
    if(Cl_low > 1)
      Cl_low= 1;
    
    Cl_diff = (Cl_up-Cl_low);
		if(Cl_diff <= 0)
      Cl_diff= 1e-100; 
	  partial_lk[j]=Cl_diff;
    }
    
    Joint_pd[i] = mean(partial_lk);
    Loglk_Y1[i] = mean(Lk_Y1);
  }
  log_like = Loglk_Y1+log(Joint_pd);
  log_like=log_like.replace(datum::nan, -230);
  return log_like;
}

 
 // [[Rcpp::export]]
 arma::mat Res_Clcpp(arma::mat xdata,arma::mat distM,arma::vec para,arma::mat Z1,arma::mat Z2,arma::mat uv,double r01,double r02){
   int a = distM.n_rows;
   arma::mat diag1(a,a),Gdist1(a,a),Gd1(a,a),W11(1,a),Gdist2(a,a),Gd2(a,a),W22(1,a),Y(a,2);
   arma::vec mu(a),mu1(a),mu2(a),log_mu2(a),W1(a),W2(a),u1(a),u2_cl(a);
   double r11,r12;
   double sd1=pow(exp(para[3]),0.5);
   double tau1=1/(1+exp(-para[11]));
   double alpha_Cl=((2*tau1)/(1-tau1));
  
   mu.zeros();
   diag1.eye();
   r11= (exp(para[4]))*(exp(para[5]));
   Gdist1 = exp(-0.5*pow((distM/exp(para[5])),2));
   Gd1 = r11*Gdist1+r01*diag1;
   
   W11 = mvrnormArma(Z1,mu, Gd1);
   W1 = W11.t();
   r12= (exp(para[9]))*(exp(para[10]));
   Gdist2 = exp(-0.5*pow((distM/exp(para[10])),2));
   Gd2 = r12*Gdist2+r02*diag1;
   
   W22 = mvrnormArma(Z2,mu, Gd2);
   W2 = W22.t();
   
   mu1 = para[0]+(para[1]*xdata.col(0))+(para[2]*xdata.col(1))+W1;
   log_mu2 = para[6]+(para[7]*(xdata.col(0))/30)+(para[8]*xdata.col(1))+W2;
   mu2 =exp(log_mu2);
   
   for(int i = 0; i < a; i++) {
   
     Y(i,0)= R::qnorm(uv(i,0),mu1[i],sd1,1,0);
     u2_cl[i] = pow((pow(uv(i,0),-alpha_Cl)*(pow(uv(i,1),(-alpha_Cl/(1+alpha_Cl)))-1)+1),(-1/alpha_Cl));
     Y(i,1)= R::qpois(u2_cl[i],mu2[i],1,0);
    
   }    
   
  return Y; 
} 
 
 
 // [[Rcpp::export]]
 double Pred_utecpp(arma::mat X_unsamp,arma::mat distM,arma::mat post1,arma::mat post2,arma::mat Z1,arma::mat Z2,arma::mat uv,arma::mat Z,double r01,double r02){ 
 int K = post1.n_rows, R = post2.n_rows, n=X_unsamp.n_rows,a = post1.n_cols ;
 double Pred_ute;
  
 arma::mat Ym(n,2);
 arma::vec post_samp1(a),post_samp2(a),log_z(R),Pz(K) ;
 
 for(int m = 0; m < K; m++) {
   post_samp1= vectorise(post1.row(m));
   Ym = Res_Clcpp(X_unsamp,distM,post_samp1,Z1,Z2,uv,r01,r02);
   for(int r = 0; r < R; r++) {
     post_samp2= vectorise(post2.row(r));
     log_z[r] = sum(Log_likelihoodCpp(X_unsamp,Ym,distM,post_samp2,Z,r01,r02));
   }
   Pz[m]=mean(exp(log_z));
 }
 Pred_ute=mean(log(Pz));
 
 return Pred_ute;
 }
 

// [[Rcpp::export]]

NumericVector LogLike_Clcpp(NumericMatrix xdata,NumericMatrix y, NumericVector para, int B, NumericMatrix W1, NumericMatrix W2) {
  int n = xdata.nrow();
  
  NumericVector mu11(n),log_mu2(n),U1(n),U2(n),U2_low(n), Loglk_Y1(n),Cl_Cop1(n),Cl_up(n),Cl_Cop2(n),Cl_low(n),Cl_diff(n),log_like(n);
  double sd1=pow(exp(para[3]),0.5);
  double tau1=1/(1+exp(-para[11]));
  double alpha_Cl=((2*tau1)/(1-tau1));
  NumericMatrix mu1(n,B), mu2(n,B), Lk_Y1(n,B),u11(n,B),u22(n,B),u22_low(n,B);
  
  for(int i = 0; i < n; i++) {
    mu11[i] = para[0]+(para[1]*xdata(i,0))+(para[2]*xdata(i,1));
    log_mu2[i] = para[6]+(para[7]*xdata(i,0))+(para[8]*xdata(i,2));
    
    for(int j = 0; j < B; j++) {
      mu1(i,j) = mu11[i]+W1(i,j);
      u11(i,j) = R::pnorm(y(i,0),mu1(i,j),sd1,1,0);
      Lk_Y1(i,j)=R::dnorm(y(i,0),mu1(i,j),sd1,1);
      mu2(i,j) = exp(log_mu2[i]+W2(i,j));
      u22(i,j)=R::ppois(y(i,1),mu2(i,j),1,0);
      u22_low(i,j)=R::ppois(y(i,1)-1,mu2(i,j),1,0);
    }
    
    U1[i] = mean(u11(i,_));
    U2[i] = mean(u22(i,_));
    U2_low[i] = mean(u22_low(i,_));
    Loglk_Y1[i] = mean(Lk_Y1(i,_));
    
    Cl_Cop1[i] = pow(pow(U1[i],-alpha_Cl)+pow(U2[i],-alpha_Cl)-1,(-1/alpha_Cl));
    if(Cl_Cop1[i] < 0)
      Cl_Cop1[i]= 0;
    if(Cl_Cop1[i] > 1)
      Cl_Cop1[i]= 1;
    
    Cl_up[i] = Cl_Cop1[i]*(pow(U1[i],(-alpha_Cl-1))/(pow(U1[i],-alpha_Cl)+pow(U2[i],-alpha_Cl)-1));
    if(Cl_up[i] < 0)
      Cl_up[i]= 0;
    if(Cl_up[i] > 1)
      Cl_up[i]= 1;
    
    Cl_Cop2[i] = pow(pow(U1[i],-alpha_Cl)+pow(U2_low[i],-alpha_Cl)-1,(-1/alpha_Cl));
    if(Cl_Cop2[i] < 0)
      Cl_Cop2[i]= 0;
    if(Cl_Cop2[i] > 1)
      Cl_Cop2[i]= 1;
    
    Cl_low[i] = Cl_Cop2[i]*(pow(U1[i],(-alpha_Cl-1))/(pow(U1[i],-alpha_Cl)+pow(U2_low[i],-alpha_Cl)-1));
    if(Cl_low[i] < 0)
      Cl_low[i]= 0;
    if(Cl_low[i] > 1)
      Cl_low[i]= 1;
    
    Cl_diff[i] = (Cl_up[i]-Cl_low[i]);
    if(Cl_diff[i] <= 0)
      Cl_diff[i]= 1e-100; 
    
    log_like[i] = Loglk_Y1[i]+log(Cl_diff[i]);
  }

  return log_like;   
}
